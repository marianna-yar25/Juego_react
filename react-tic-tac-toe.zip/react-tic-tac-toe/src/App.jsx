import { useState, useEffect } from "react";
import "./App.css";

function Square({ value, onClick, isWinner }) {
  return (
    <button
      className={`square ${isWinner ? "winner" : ""}`}
      onClick={onClick}
      disabled={!!value}
    >
      {value}
    </button>
  );
}

function Board({ squares, onClick, winnerLine }) {
  return (
    <div className="board">
      {squares.map((value, i) => (
        <Square
          key={i}
          value={value}
          onClick={() => onClick(i)}
          isWinner={winnerLine?.includes(i)}
        />
      ))}
    </div>
  );
}

export default function Game() {
  const [squares, setSquares] = useState(Array(9).fill(null));
  const [xIsNext, setXIsNext] = useState(true);
  const [scores, setScores] = useState({ X: 0, O: 0 });
  const [winner, setWinner] = useState(null);
  const [winnerLine, setWinnerLine] = useState(null);

  function handleClick(i) {
    // Si ya hay ganador o esa casilla está ocupada, no hace nada
    if (squares[i] || winner) return;

    const nextSquares = squares.slice();
    nextSquares[i] = xIsNext ? "X" : "O";
    setSquares(nextSquares);
    setXIsNext(!xIsNext);
  }

  useEffect(() => {
    const { player, line } = calculateWinner(squares);

    if (player) {
      setWinner(player);
      setWinnerLine(line);
      setScores((prev) => ({
        ...prev,
        [player]: prev[player] + 1,
      }));

      // Reinicia el tablero después de un pequeño delay
      setTimeout(() => resetBoard(), 1500);
    } else if (squares.every(Boolean) && !player) {
      setWinner("Empate");
      setTimeout(() => resetBoard(), 1500);
    }
  }, [squares]);

  function resetBoard() {
    setSquares(Array(9).fill(null));
    setWinner(null);
    setWinnerLine(null);
    setXIsNext(true);
  }

  function resetScores() {
    setScores({ X: 0, O: 0 });
    resetBoard();
  }

  return (
    <div className="container">
      <h1> Gato</h1>

      <div className="scoreboard">
        <div className="score">❌ : {scores.X}</div>
        <div className="score">⭕ : {scores.O}</div>
      </div>

      <div className="status">
        {winner
          ? winner === "Empate"
            ? "🤝 ¡Empate!"
            : `🏆 ¡Ganó ${winner}!`
          : `Turno de ${xIsNext ? "❌ " : "⭕ "}`}
      </div>

      <Board squares={squares} onClick={handleClick} winnerLine={winnerLine} />

      <button className="btn" onClick={resetScores}>
        Reiniciar Marcador
      </button>

      <footer>React.js</footer>
    </div>
  );
}

function calculateWinner(squares) {
  const lines = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6],
  ];

  for (let [a, b, c] of lines) {
    if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
      return { player: squares[a], line: [a, b, c] };
    }
  }
  return { player: null, line: null };
}
